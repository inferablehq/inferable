using Inferable;

public static class Register
{
    public static void RegisterTools(InferableClient client)
    {
    }
}
